# ************************************************************
# Sequel Pro SQL dump
# Версия 4529
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Адрес: localhost (MySQL 5.7.12)
# Схема: trello
# Время создания: 2017-09-11 15:45:33 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Дамп таблицы attach_file
# ------------------------------------------------------------

DROP TABLE IF EXISTS `attach_file`;

CREATE TABLE `attach_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `itemId` int(11) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `mime` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `file_model` (`model`),
  KEY `file_item_id` (`itemId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Дамп таблицы catalog
# ------------------------------------------------------------

DROP TABLE IF EXISTS `catalog`;

CREATE TABLE `catalog` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Дамп таблицы catalog_item
# ------------------------------------------------------------

DROP TABLE IF EXISTS `catalog_item`;

CREATE TABLE `catalog_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catalog_id` int(11) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `image_text` varchar(255) DEFAULT NULL,
  `favorite` varchar(255) DEFAULT NULL,
  `num_rows` int(11) DEFAULT NULL,
  `num_seats` int(11) DEFAULT NULL,
  `total_num_seats` int(11) DEFAULT NULL,
  `specification` varchar(255) DEFAULT NULL,
  `placement` varchar(255) DEFAULT NULL,
  `comment` text,
  PRIMARY KEY (`id`),
  KEY `sku` (`sku`),
  KEY `catalog_id` (`catalog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Дамп таблицы catalog_item_old
# ------------------------------------------------------------

DROP TABLE IF EXISTS `catalog_item_old`;

CREATE TABLE `catalog_item_old` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catalog_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `catalog_id` (`catalog_id`),
  KEY `active` (`active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Дамп таблицы catalog_item_old2
# ------------------------------------------------------------

DROP TABLE IF EXISTS `catalog_item_old2`;

CREATE TABLE `catalog_item_old2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catalog_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sku` varchar(255) DEFAULT NULL,
  `specification` text,
  `placement` varchar(255) DEFAULT NULL,
  `places_num` int(11) DEFAULT NULL,
  `comment` text,
  PRIMARY KEY (`id`),
  KEY `catalog_id` (`catalog_id`),
  KEY `sku` (`sku`),
  KEY `image` (`image`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Дамп таблицы client_catalog_item
# ------------------------------------------------------------

DROP TABLE IF EXISTS `client_catalog_item`;

CREATE TABLE `client_catalog_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `catalog_item_sku` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  KEY `catalog_item_sku` (`catalog_item_sku`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Дамп таблицы client_order
# ------------------------------------------------------------

DROP TABLE IF EXISTS `client_order`;

CREATE TABLE `client_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Дамп таблицы client_order_item
# ------------------------------------------------------------

DROP TABLE IF EXISTS `client_order_item`;

CREATE TABLE `client_order_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `catalog_item_id` varchar(255) DEFAULT NULL,
  `type` enum('design','catalog') DEFAULT 'design',
  `qty` int(11) DEFAULT NULL,
  `comment` text,
  `placement` varchar(255) DEFAULT NULL,
  `places_num` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  KEY `order_id` (`order_id`),
  KEY `catalog_item_id` (`catalog_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Дамп таблицы Lang
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Lang`;

CREATE TABLE `Lang` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `local` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `default` smallint(6) NOT NULL DEFAULT '0',
  `date_update` int(11) NOT NULL,
  `date_create` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Дамп таблицы my_galleries_items_photo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `my_galleries_items_photo`;

CREATE TABLE `my_galleries_items_photo` (
  `id_item` int(10) NOT NULL AUTO_INCREMENT,
  `gallery_id` int(10) NOT NULL,
  `name_item` varchar(250) NOT NULL,
  `file_id` int(10) NOT NULL,
  PRIMARY KEY (`id_item`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Дамп таблицы my_galleries_photomarkup
# ------------------------------------------------------------

DROP TABLE IF EXISTS `my_galleries_photomarkup`;

CREATE TABLE `my_galleries_photomarkup` (
  `id_gallery` int(10) NOT NULL AUTO_INCREMENT,
  `name_gallery` varchar(250) CHARACTER SET utf8 NOT NULL,
  `commwnt_gallery` varchar(250) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id_gallery`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Дамп таблицы my_googleforms
# ------------------------------------------------------------

DROP TABLE IF EXISTS `my_googleforms`;

CREATE TABLE `my_googleforms` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `google_id` varchar(100) NOT NULL,
  `google_id_editmode` varchar(100) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `mfiles_meta_class_id` int(6) NOT NULL,
  `mfiles_meta_dropdwn_001_id` int(6) NOT NULL,
  `mfiles_meta_dropdwn_002_id` int(6) NOT NULL,
  `internal_message` varchar(250) CHARACTER SET utf8 NOT NULL,
  `internal_emails` varchar(500) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Дамп таблицы settings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `desc` text NOT NULL,
  `type` varchar(255) DEFAULT 'string',
  `section` varchar(255) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `value` text,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Дамп таблицы user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
